Watson Code Assistant for Z Data Generator - 1.0.0

Generates Control Flow data and DDL database information from an extracted service and writes the information in a DB2 on Cloud database.


### Prerequisites

1. The basic requirements for running the Watson Code Assistant for Z Data Generator (WCA4Z) are the same as IBM Application Discovery and Delivery Intelligence (ADDI) and can be found at https://www.ibm.com/docs/en/addi/6.1.2?topic=installing-prerequisites.
1. ADDI is already installed and configured on the same machine where Watson Code Assistant for Z Data Generator is going to be installed. More information available at https://www.ibm.com/docs/en/addi/6.1.2?topic=guide-installing


### Setup

1. Extract the contents of the WCA4Z Data Generator ZIP file into the `<ADDI_INSTALLATION_FOLDER>` folder. The ZIP file contains a folder called `WCA4Z Data Generator` so after extracting, the contents of that folder should be available in `<ADDI_INSTALLATION_FOLDER>\WCA4Z Data Generator`.
2. Add an IBM Db2 relational database server from `IBM Application Discovery Configuration Service Admin > Configure > <ENV_NAME> > Servers and security > Relational database servers.`. This should be an instance of IBM Db2 on Cloud.
3. Create a new mainframe project:
    - Open `IBM Application Discovery Build Client`.
    - Select `File > New Project`.
    - Choose `Mainframe main languages` as the project type and click on the `Next` button.
    - Enter a the project name, for example `ExtractedServices`. 
    - Select the `Project DB Type` and choose the IBM Db2 on Cloud database server added in the previous step.
    - Click on the `Finish` button to create the new project.
4. Create a new GitHub repository for the source files extracted from IBM Refactoring Assistant. The structure of the repository should the following folders:
    - `Cobol Programs`
    - `Copybooks`
    - `DDL`
5. Enable project file synchronization. More information available at https://www.ibm.com/docs/en/addi/6.1.2?topic=configurations-filling-ad-build-client-install-configuration-page
    - Copy the file `<ADDI_INSTALLATION_FOLDER>\WCA4Z Data Generator\samples\SyncFile.txt` to a new location, for example the ADDI project sources folder `C:\IBM AD\Mainframe Sources`.
    - Open `IBM Application Discovery Configuration Service Admin > Configure > Install configurations > IBM Application Discovery Build Client install configuration`.
    - Check the "Enable members synchronization" option.
    - Fill in the full path to the `SyncFile.txt`, for example `C:\IBM AD\Mainframe Sources\SyncFile.txt`.
    - Save the changes by clicking on the `Save` button.
6. Open the configuration file located in `<ADDI_INSTALLATION_FOLDER>\WCA4Z Data Generator\conf.properties`.
7. Edit the values to match your ADDI installation details. Default values are provided as an example and they could be used as is or modified.
    - `ADDI_PROJECT_NAME=ExtractedServices` - This is the project created in IBM Application Discovery Build Client and will be used to build the extracted services COBOL files.
    - `ADDI_PROJECTS_FOLDER=C:\IBM AD\Mainframe Projects` - This is the root folder for all projects. It has been configured during the ADDI initial setup and it can be accessed from `IBM Application Discovery Configuration Service Admin > Configure > Install configurations > IBM Application Discovery Build Client install configuration`.
    - `PROJECT_GITHUB_CLONE_FOLDER=C:\Extracted-Services` - This is the GitHub repository folder where the extracted services COBOL files are committed and updated.
    - `DDL_FOLDER=C:\Extracted-Services\DDL` - This is the folder where DDL and JCL files containing database information are added. Multiple files can be added to the folder but only the most recently updated one will be processed.

### Run

1. Run the `automation.bat` script with no additional arguments from Command Prompt.
2. The script is executing synchronously and will return a zero exit code for a successful execution or a non zero exit code otherwise.
3. If new programs have been built successfully but the metadata import fails for any reason, those programs will be saved for retry with the next run.
4. A new `runControlFlowGenerator.log` log file will be generated in the same folder containing the full output of the execution.